using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject[] gameObjects;
    public GameObject[] characters;
    public GameObject[] items;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Invoke("Spawn", 2f);
        Invoke("SpawnCharacters", 2f);
        Invoke("SpawnChuru", Random.Range(10, 30));
        Invoke("SpawnGoldChuru", Random.Range(10, 50));
    }

  

    public void Spawn()
    {
        GameObject randomObject = gameObjects[Random.Range(0, gameObjects.Length)];
        Instantiate(randomObject, transform.position, Quaternion.identity);
        Invoke("Spawn", Random.Range(1,3));
    }

    public void SpawnCharacters()
    {
        GameObject randomObject = characters[Random.Range(0, characters.Length)];
        Instantiate(randomObject, new Vector3(transform.position.x, -5.1f, transform.position.z), Quaternion.identity);
        Invoke("SpawnCharacters", Random.Range(0, 4));
    }

    public void SpawnChuru()
    {
        Instantiate(items[0], new Vector3(transform.position.x, 0f, transform.position.z), Quaternion.identity);
        Invoke("SpawnChuru", Random.Range(10, 30));
    }

    public void SpawnGoldChuru()
    {
        Instantiate(items[1], new Vector3(transform.position.x, 0f, transform.position.z), Quaternion.identity);
        Invoke("SpawnGoldChuru", Random.Range(10, 50));
    }
}
