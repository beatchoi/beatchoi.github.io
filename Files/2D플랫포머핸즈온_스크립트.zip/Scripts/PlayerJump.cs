using UnityEngine;

public class PlayerJump : MonoBehaviour
{
    public float jumpForce;
    Rigidbody2D rb;
    bool isGrounded;

    private int life = 3;
    private bool isInvincible = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.AddForceY(jumpForce, ForceMode2D.Impulse);
            isGrounded = false;
        }

       
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isGrounded = true;

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "enemy")
        {
            GameManager.instance.life -= 1;
            if (GameManager.instance.life <= 0)
            {
                rb.AddForceY(jumpForce, ForceMode2D.Impulse);
                transform.GetComponent<BoxCollider2D>().enabled = false;
            }
        }
        else if(collision.gameObject.tag == "churu")
        {
           GameManager.instance.life += 1;
           Destroy(collision.transform.gameObject);
        }
        else if (collision.gameObject.tag == "goldchuru")
        {
            Destroy(collision.transform.gameObject);
        }
    }
}
