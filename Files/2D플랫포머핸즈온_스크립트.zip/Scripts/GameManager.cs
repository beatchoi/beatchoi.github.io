using UnityEngine;


public enum GameState
{
    intro,
    playing,
    end
}
public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public GameState State;
    public GameObject Spawner;

    public int life = 3;

    private void Awake()
    {
        instance = this;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        State = GameState.intro;
    }

    // Update is called once per frame
    void Update()
    {
        if(life <= 0)
        {
            State = GameState.end;

        }
    }
}
